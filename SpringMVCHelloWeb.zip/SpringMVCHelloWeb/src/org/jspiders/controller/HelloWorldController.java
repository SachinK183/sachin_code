package org.jspiders.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HelloWorldController {
	
	@RequestMapping(value="/" , method = RequestMethod.GET)
	public String sayWelcomeFile() {
		return "wc";
	}
	
	@RequestMapping(value="/hello" , method = RequestMethod.GET)
	public String sayHelloWorld(ModelMap model) {
		model.addAttribute("message", "Ye Hay JohnDevCena Ka Spring Hello");
		return "hello";
	}
	
	
	
	
	
	
	@RequestMapping(value="/redirect" , method = RequestMethod.GET)
	public String sayRedirect() {
		return "redirect:redirectPage";
	}
	
	
	@RequestMapping(value="/redirectPage" , method = RequestMethod.GET)
	public String doRedirect() {
		return "redirect";
	}
}