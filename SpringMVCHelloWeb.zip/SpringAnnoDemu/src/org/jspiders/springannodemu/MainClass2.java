package org.jspiders.springannodemu;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass2 {
	public static void main(String[] args) {
		System.out.println("Program Started");
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		context.registerShutdownHook();
		Circle c1 = (Circle)context.getBean("circle");
		System.out.println(c1);
		System.out.println("Program Ended");
	}
}
