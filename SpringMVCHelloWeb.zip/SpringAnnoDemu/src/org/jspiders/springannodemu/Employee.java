package org.jspiders.springannodemu;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Employee {
	private int id;
	private String name;

	private Car car;
	
	public Car getCar() {
		return car;
	}
	
	@Autowired
	@Qualifier("employeeRelatedCar")
	public void setCar(Car car) {
		this.car = car;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public String toString() {
		return "Employee[Name : "+name+" Id : "+id+" CarName : "+car.getNaam()+" CarColor : "+car.getRang()+"]";
	}
}
