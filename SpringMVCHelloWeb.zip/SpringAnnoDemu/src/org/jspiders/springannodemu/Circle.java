package org.jspiders.springannodemu;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

import org.springframework.stereotype.Component;

@Component
public class Circle {
	private Point center;

	public Point getCenter() {
		return center;
	}
	
	@Resource
	public void setCenter(Point center) {
		this.center = center;
	}
	
	@Override
	public String toString() {
		return "Circle[x = "+center.getX()+", y = "+center.getY()+"]";
	}
	
	@PostConstruct
	public void circleKaInit()
	{
		System.out.println("Running Circle Ka Init method. . .");
	}
	
	@PreDestroy
	public void circleKaDestroy()
	{
		System.out.println("Running Circle Ka Destroy method. . .");
	}
}

