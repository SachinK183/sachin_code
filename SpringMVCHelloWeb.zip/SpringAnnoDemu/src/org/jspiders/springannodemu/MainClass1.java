package org.jspiders.springannodemu;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass1 {
	public static void main(String[] args) {
		System.out.println("Program Started");
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		Employee e1 = (Employee)context.getBean("employee1");
		System.out.println(e1);
		System.out.println("Program Ended");
	}
}
